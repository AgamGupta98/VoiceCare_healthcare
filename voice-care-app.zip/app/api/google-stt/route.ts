import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { audio } = await request.json()

    // Use Google Cloud Speech-to-Text
    const response = await fetch(
      `https://speech.googleapis.com/v1/speech:recognize?key=${process.env.GOOGLE_CLOUD_API_KEY || "DEMO_MODE"}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          config: {
            encoding: "WEBM_OPUS",
            sampleRateHertz: 48000,
            languageCode: "en-US",
            enableAutomaticPunctuation: true,
            model: "default",
          },
          audio: {
            content: audio,
          },
        }),
      },
    )

    if (!response.ok) {
      // Fallback to mock transcription for demo
      return NextResponse.json({
        transcript:
          "This is a demo transcription. Please add GOOGLE_CLOUD_API_KEY to enable real Google Speech-to-Text.",
      })
    }

    const data = await response.json()
    const transcript = data.results?.[0]?.alternatives?.[0]?.transcript || "Could not transcribe audio"

    return NextResponse.json({ transcript })
  } catch (error) {
    console.error("Error in Google STT:", error)
    return NextResponse.json(
      {
        transcript: "Demo mode: Please add your Google Cloud API key to use real speech recognition.",
        error: "API key not configured",
      },
      { status: 200 },
    )
  }
}
