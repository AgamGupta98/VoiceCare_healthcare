// Utility functions for MedEcho

/**
 * Creates a page URL for navigation
 * In the current app structure, this returns a hash-based route
 * that can be used with the state-based navigation system
 */
export function createPageUrl(pageName: string): string {
  // For now, return a simple path that works with the existing navigation
  // This could be extended to support proper routing if needed
  return `#${pageName.toLowerCase()}`
}

/**
 * Get the current user ID from localStorage
 * Used as a fallback for getting user context
 */
export function getCurrentUserId(): string {
  const user = localStorage.getItem("medecho_current_user")
  if (user) {
    try {
      const parsed = JSON.parse(user)
      return parsed.id || "demo_user"
    } catch {
      return "demo_user"
    }
  }
  return "demo_user"
}

/**
 * Format phone number to Indian format
 */
export function formatPhoneNumber(phone: string): string {
  // Remove all non-digits
  const cleaned = phone.replace(/\D/g, "")

  // Format as +91-XXXXX-XXXXX
  if (cleaned.length === 10) {
    return `+91-${cleaned.slice(0, 5)}-${cleaned.slice(5)}`
  }

  return phone
}

/**
 * Calculate age from date of birth
 */
export function calculateAge(dateOfBirth: string): number {
  const today = new Date()
  const birthDate = new Date(dateOfBirth)
  let age = today.getFullYear() - birthDate.getFullYear()
  const monthDiff = today.getMonth() - birthDate.getMonth()

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--
  }

  return age
}

/**
 * Speak text using Web Speech API
 * Supports bilingual Hindi/English announcements
 */
export function speak(text: string, lang = "hi-IN"): void {
  if ("speechSynthesis" in window) {
    // Cancel any ongoing speech
    window.speechSynthesis.cancel()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = lang
    utterance.rate = 0.9 // Slightly slower for clarity
    window.speechSynthesis.speak(utterance)
  }
}

/**
 * Format currency to Indian Rupees
 */
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(amount)
}

/**
 * Get distance display text
 */
export function formatDistance(km: number): string {
  if (km < 1) {
    return `${Math.round(km * 1000)}m away`
  }
  return `${km.toFixed(1)}km away`
}
